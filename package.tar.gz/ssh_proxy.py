#!/usr/bin/env python3
"""
SSH代理主程序：实现SSH连接的Proxy Protocol解析、端口映射和IP封禁功能
"""

import errno
import os
import re
import select
import socket
import threading
import time
from datetime import datetime

from proxy_protocol import ProxyProtocolParser
from connection_manager import ConnectionManager
from ban_manager import BanManager
from config import load_config, validate_config, load_state, save_state
import constants
from constants import ensure_file_path

from cfpackages.logger_formatter import get_logger

logger = get_logger(__name__, constants.DEFAULT_LOG_LEVEL)


class SSHProxy:
    """SSH代理主类"""

    def __init__(self):
        # 加载配置
        self.config = load_config()
        
        # 验证配置
        is_valid, error_msg = validate_config(self.config)
        if not is_valid:
            raise ValueError(f"配置无效: {error_msg}")
        
        # 初始化组件 - 传递所有封禁相关参数
        self.ban_manager = BanManager(
            ban_duration=self.config["ban_duration"],
            max_failures=self.config["failures_to_ban"],
            failure_window=self.config["failure_window"]
        )
        self.conn_manager = ConnectionManager(
            max_connections=self.config["max_connections"],
            connection_timeout=self.config["connection_timeout"],
        )

        # 需要断开的连接
        self.connections_to_close = set()
        self.connections_lock = threading.Lock()

        # 服务器socket
        self.server_socket = None
        self.running = False

        # 加载运行时状态（如日志扫描位置）
        self.state = load_state()

        logger.info("SSH代理初始化完成")
        logger.info("封禁阈值: %s次/%s秒", self.config["failures_to_ban"], self.config["failure_window"])

    def create_sshd_connection(self):
        """创建到sshd的连接"""
        try:
            # 创建socket
            sshd_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sshd_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

            # 绑定到随机端口（用于端口映射）
            sshd_sock.bind(("0.0.0.0", 0))

            # 获取本地端口
            local_port = sshd_sock.getsockname()[1]

            # 连接到sshd
            sshd_sock.connect((self.config["sshd_host"], self.config["sshd_port"]))

            # 设置非阻塞
            sshd_sock.setblocking(False)

            return sshd_sock, local_port

        except (socket.error, OSError) as e:
            logger.error("创建sshd连接失败: %s", e)
            return None, None

    def should_close_connection(self, thread_id):
        """检查连接是否需要关闭"""
        with self.connections_lock:
            return thread_id in self.connections_to_close

    def mark_connection_for_closing(self, thread_id):
        """标记连接需要关闭"""
        with self.connections_lock:
            self.connections_to_close.add(thread_id)

    def _handle_socket_data(self, src_sock, dst_sock, thread_id, direction):
        """处理socket数据传输"""
        try:
            data = src_sock.recv(constants.DEFAULT_BUFFER_SIZE)
            if data:
                # 发送数据，处理非阻塞
                total_sent = 0
                while total_sent < len(data):
                    try:
                        sent = dst_sock.send(data[total_sent:])
                        if sent == 0:
                            return False  # 连接关闭
                        total_sent += sent
                    except BlockingIOError:
                        continue  # 稍后重试
                    except socket.error as e:
                        if e.errno in (errno.EAGAIN, errno.EWOULDBLOCK):
                            continue
                        return False
                if direction == "sent":
                    self.conn_manager.update_activity(thread_id, sent=len(data))
                else:
                    self.conn_manager.update_activity(thread_id, received=len(data))
                return True
            return False
        except BlockingIOError:
            return True
        except ConnectionResetError:
            return False
        except socket.error as e:
            if e.errno in (errno.EAGAIN, errno.EWOULDBLOCK):
                return True
            return False

    def forward_connection(self, client_sock, sshd_sock, client_info, local_port):
        """转发连接数据"""
        thread_id = threading.get_ident()
        conn_id = None
        client_ip = client_info['ip']  # 获取客户端IP用于检查

        # 添加到连接管理器
        if not self.conn_manager.add_connection(thread_id, client_info, local_port):
            logger.error("连接数达到上限，拒绝连接: %s", client_info['ip'])
            client_sock.close()
            sshd_sock.close()
            return

        try:
            # 设置非阻塞
            client_sock.setblocking(False)

            # 超时时间
            timeout = self.config["connection_timeout"]
            last_activity = time.time()

            # 获取连接ID用于日志
            with self.conn_manager.lock:
                if thread_id in self.conn_manager.active_connections:
                    conn_id = self.conn_manager.active_connections[thread_id].get(
                        "conn_id"
                    )

            while time.time() - last_activity < timeout:
                # 检查1: 线程是否被标记关闭
                if self.should_close_connection(thread_id):
                    logger.info("连接 #%s 被标记为关闭", conn_id)
                    break
                # 检查2: IP是否被封禁
                if self.ban_manager.is_banned(client_ip):
                    logger.info("连接 #%s 的IP(%s)已被封禁，主动断开", conn_id, client_ip)
                    break

                # 使用select等待数据
                rlist, _, xlist = select.select(
                    [client_sock, sshd_sock], [], [client_sock, sshd_sock], constants.SELECT_TIMEOUT
                )

                if xlist:
                    logger.info("连接 #%s 异常", conn_id)
                    break

                data_transferred = False
                for sock in rlist:
                    if sock is client_sock:
                        if not self._handle_socket_data(
                            client_sock, sshd_sock, thread_id, "sent"
                        ):
                            logger.info("连接 #%s 客户端关闭连接", conn_id)
                            return
                        data_transferred = True
                    elif sock is sshd_sock:
                        if not self._handle_socket_data(
                            sshd_sock, client_sock, thread_id, "received"
                        ):
                            logger.info("连接 #%s sshd关闭连接", conn_id)
                            return
                        data_transferred = True

                if data_transferred:
                    last_activity = time.time()
                else:
                    time.sleep(0.01)

            logger.info("连接 #%s 超时", conn_id)

        except (select.error, socket.error) as e:
            logger.error("连接 #%s 转发数据时出错: %s", conn_id, e)
        finally:
            # 记录调试信息
            logger.debug("开始清理连接 #%s (端口: %s)", conn_id, local_port)
            
            # 关闭socket
            try:
                client_sock.close()
            except:
                pass
            try:
                sshd_sock.close()
            except:
                pass
            
            # 简单地从连接管理器中移除（不立即删除端口映射）
            with self.conn_manager.lock:
                if thread_id in self.conn_manager.active_connections:
                    # 保存连接信息到临时变量，用于可能的日志匹配
                    conn_info = self.conn_manager.active_connections[thread_id]
                    # 标记为已关闭
                    conn_info["closed"] = True
                    conn_info["closed_time"] = time.time()
                    
                    # 不立即删除端口映射，但标记为关闭
                    local_port = conn_info["local_port"]
                    if local_port in self.conn_manager.port_mapping:
                        self.conn_manager.port_mapping[local_port]["closed"] = True
                        self.conn_manager.port_mapping[local_port]["closed_time"] = time.time()
                    
                    # 从活动连接字典中移除
                    del self.conn_manager.active_connections[thread_id]
            
            logger.debug("连接 #%s 清理完成", conn_id)

    def handle_client(self, client_sock, client_addr):
        """处理客户端连接"""
        sshd_sock = None
        try:
            # 先设置超时，避免客户端不发送数据
            client_sock.settimeout(constants.CONNECTION_TIMEOUT)

            # 解析Proxy Protocol
            logger.debug("开始解析Proxy Protocol...")
            real_ip, real_port = ProxyProtocolParser.parse(client_sock)
            logger.debug("解析完毕!")

            if real_ip is None:
                # 不是Proxy Protocol，使用连接地址
                real_ip, real_port = client_addr
                logger.info("使用连接地址: %s:%s", real_ip, real_port)
            else:
                logger.info("解析到真实客户端: %s:%s", real_ip, real_port)

            # 设置合理的超时而不是完全移除
            client_sock.settimeout(constants.DEFAULT_SOCKET_TIMEOUT)

            client_info = {
                "ip": real_ip,
                "port": real_port,
                "connect_time": time.time(),
            }

            # 检查IP是否被封禁
            if self.ban_manager.is_banned(real_ip):
                ban_info = self.ban_manager.get_ban_info(real_ip)
                remaining = ban_info.get("remaining_seconds", 0) if ban_info else 0
                logger.warning(
                    "拒绝被封禁IP的连接: %s，剩余封禁时间: %s秒", real_ip, remaining
                )

                # 发送拒绝消息，设置发送超时
                try:
                    client_sock.settimeout(1.0)  # 设置发送超时
                    client_sock.sendall(
                        b"Connection refused: Your IP has been blocked.\n"
                    )
                except (socket.error, OSError):
                    pass
                finally:
                    client_sock.close()
                return

            # 创建到sshd的连接
            sshd_sock, local_port = self.create_sshd_connection()
            if sshd_sock is None:
                logger.error("无法连接到sshd: %s", real_ip)
                client_sock.close()
                return

            logger.info("端口映射: %s:%s -> 127.0.0.1:%s", real_ip, real_port, local_port)

            # 开始转发
            self.forward_connection(client_sock, sshd_sock, client_info, local_port)

        except socket.timeout:
            logger.warning("连接超时: %s", client_addr)
        except (socket.error, OSError) as e:
            logger.error("处理客户端连接时出错: %s", e)
        except Exception as e:
            logger.error("处理客户端连接时发生未预期的错误: %s", e, exc_info=True)
        finally:
            # 确保关闭客户端socket
            try:
                client_sock.close()
            except:
                pass
            # 如果sshd_sock被创建但forward_connection没有接手管理，也关闭它
            # 注意：在正常情况下，forward_connection会负责关闭sshd_sock
            # 只有在create_sshd_connection成功但forward_connection未被调用时才需要在这里关闭
            if sshd_sock is not None:
                # 检查是否已经进入forward_connection（通过检查连接管理器）
                # 如果连接管理器中没有这个线程，则说明forward_connection没有被调用
                thread_id = threading.get_ident()
                with self.conn_manager.lock:
                    if thread_id not in self.conn_manager.active_connections:
                        try:
                            sshd_sock.close()
                        except:
                            pass

    def _ensure_sshd_log_file(self, log_file):
        """确保SSH日志文件存在且可访问"""
        try:
            if not log_file:
                logger.error("SSH日志文件路径为空")
                return False
            
            # 检查是否是文件（如果已存在）
            if os.path.exists(log_file):
                if not os.path.isfile(log_file):
                    logger.error("SSH日志路径不是文件: %s", log_file)
                    return False
                return True
            
            # 确保父目录存在
            if not ensure_file_path(log_file):
                return False
            
            # 创建空文件
            with open(log_file, 'w', encoding='utf-8') as f:
                pass
            logger.info("创建SSH日志文件: %s", log_file)
            return True
            
        except (OSError, IOError, PermissionError) as e:
            logger.error("创建SSH日志文件失败 %s: %s", log_file, e)
            return False

    def _scan_logs(self):
        """
        扫描SSH日志文件，处理认证失败记录
        """
        log_file = self.config["sshd_log_path"]
        
        # 确保日志文件存在
        if not self._ensure_sshd_log_file(log_file):
            logger.error("无法访问SSH日志文件: %s", log_file)
            return

        try:
            # 1. 先读取所有新日志行
            current_size = os.path.getsize(log_file)
            last_position = self.state.get("last_position", 0)

            if current_size < last_position:
                logger.info("检测到日志文件轮转，从头开始读取")
                self.state["last_position"] = 0
                last_position = 0

            if current_size > last_position:
                new_lines = []
                with open(log_file, "r", encoding="utf-8", errors="ignore") as f:
                    f.seek(last_position)
                    new_lines = f.readlines()
                    self.state["last_position"] = f.tell()

                logger.info("读取了 %s 行新日志", len(new_lines))

                # 2. 处理每一行（不使用ConnectionManager的锁保护整个过程）
                for line in new_lines:
                    line = line.strip()
                    if not line:
                        continue
                    
                    # 检查认证失败
                    for pattern in constants.FAILURE_PATTERNS:
                        match = re.search(pattern, line)
                        if match:
                            source_ip = match.group(1)
                            try:
                                source_port = int(match.group(2))
                            except (ValueError, IndexError):
                                source_port = 0

                            # 记录到失败日志
                            failures_log = constants.AUTH_FAILURES_LOG
                            if ensure_file_path(failures_log):
                                with open(failures_log, "a", encoding="utf-8") as f:
                                    f.write(f"{datetime.now()} - {line}\n")

                            # 3. 获取客户端信息（快速检查，不持有锁太久）
                            client_info = None
                            with self.conn_manager.lock:
                                if source_port in self.conn_manager.port_mapping:
                                    client_info = self.conn_manager.port_mapping[source_port]
                            
                            if client_info:

                                logger.info(
                                    "检测到认证失败: %s:%s - %s...",
                                    source_ip,
                                    source_port,
                                    line[:100],
                                )
                                real_ip = client_info["ip"]
                                
                                # 记录失败
                                failures = self.ban_manager.record_failure(real_ip, source_port)
                                logger.warning("IP %s 认证失败，累计 %s 次", real_ip, failures)
                                
                                # 如果被封禁，断开连接
                                if self.ban_manager.is_banned(real_ip):
                                    logger.warning("IP %s 已被封禁，断开连接", real_ip)
                                    threads = self.conn_manager.disconnect_ip(real_ip)
                                    for thread_id in threads:
                                        self.mark_connection_for_closing(thread_id)
                            else:
                                # 没有找到端口映射
                                logger.debug("未找到端口 %s 的映射", source_port)
                            # 匹配到一个模式就跳出
                            break

        except (FileNotFoundError, OSError, IOError) as e:
            logger.error("扫描日志时出错: %s", e)

    def monitor_sshd_logs(self):
        """监控sshd日志的线程函数"""
        while self.running:
            self._scan_logs()
            # 休眠，等待下次扫描
            time.sleep(self.config["log_scan_interval"])

    def start_log_monitor(self):
        """启动日志监控线程"""
        monitor_thread = threading.Thread(target=self.monitor_sshd_logs, daemon=True)
        monitor_thread.start()
        return monitor_thread

    def start(self):
        """启动代理服务器"""
        try:
            # 创建服务器socket
            self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.server_socket.bind(
                (self.config["listen_host"], self.config["listen_port"])
            )
            self.server_socket.listen(10)

            self.running = True

            logger.info(
                "SSH代理启动在 %s:%s",
                self.config['listen_host'],
                self.config['listen_port']
            )
            logger.info("转发到 %s:%s", self.config['sshd_host'], self.config['sshd_port'])
            logger.info("最大连接数: %s", self.config['max_connections'])

            # 启动日志监控
            self.start_log_monitor()

            # 接受连接循环
            while self.running:
                try:
                    client_sock, client_addr = self.server_socket.accept()
                    logger.info("接受新连接: %s", client_addr)

                    # 在新线程中处理连接
                    thread = threading.Thread(
                        target=self.handle_client,
                        args=(client_sock, client_addr),
                        daemon=True,
                    )
                    thread.start()

                except KeyboardInterrupt:
                    logger.info("收到中断信号，正在关闭...")
                    self.running = False
                    break
                except (socket.error, OSError) as e:
                    logger.error("接受连接时出错: %s", e)
                    if self.running:
                        time.sleep(1)

        except (socket.error, OSError) as e:
            logger.error("启动服务器时出错: %s", e)
        finally:
            self.stop()

    def stop(self):
        """停止代理服务器"""
        self.running = False

        if self.server_socket:
            try:
                self.server_socket.close()
                logger.info("服务器socket已关闭")
            except (socket.error, OSError):
                pass

        # 保存状态和黑名单
        self.ban_manager.save_blacklist()
        save_state(self.state)
        logger.info("状态和黑名单已保存")


def main():
    """主函数"""
    # 创建并启动代理
    proxy = SSHProxy()

    try:
        proxy.start()
    except KeyboardInterrupt:
        logger.info("正在关闭代理...")
        proxy.stop()
    except (socket.error, OSError) as e:
        logger.error("代理运行出错: %s", e)
        proxy.stop()


if __name__ == "__main__":
    main()
